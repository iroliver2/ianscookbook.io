const PREFIX = "/api";

export const config = {
  PREFIX,
};

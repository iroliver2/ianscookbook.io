export type BoundT = {
  id?: string | number | null;
};

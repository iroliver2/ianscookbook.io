export { useLocales } from "./use-locales";

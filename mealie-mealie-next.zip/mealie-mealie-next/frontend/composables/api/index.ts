export { useStaticRoutes } from "./static-routes";
export { useAdminApi, usePublicApi, usePublicExploreApi, useUserApi } from "./api-client";
